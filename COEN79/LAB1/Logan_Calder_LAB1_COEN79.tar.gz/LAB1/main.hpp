// Logan Calder, COEN79L TH 2:10
// Lab #1, .hpp File
#ifndef main_hpp
#define main_hpp

// Including libraries needed for files
#include <stdio.h>
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

// Declaring the reverseString(string s) method
string reverseString(string s);

#endif /* main_hpp */