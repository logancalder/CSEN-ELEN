// Logan Calder, COEN79 TTH 8:30
// Homework #1, Problem #8, Page 15 of Textbook
// setup_cout_fractions(int fraction_digits) provided by textbook, credit:
// Data Structures and other Objects using C++, by Michael Main, Walter Savitch, 4th Edition

#ifndef main_h
#define main_h

#include <stdio.h>
#include <iostream>
#include <iomanip>

double feet_to_meters(double feet);

void setup_cout_fractions(int fraction_digits);

#endif /* main_h */
